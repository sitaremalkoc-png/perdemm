---
title: Perde AI Studio - Private Model Gateway
emoji: 🪟
colorFrom: stone
colorTo: orange
sdk: gradio
sdk_version: 5.46.1
app_file: app.py
pinned: false
license: apache-2.0
---

# Perde AI Studio - Private ZeroGPU Space

This optional Space is intended for the user's own Hugging Face account after it becomes eligible to host a free ZeroGPU Space (verified email and account older than 30 days). Keep the Space **Private**. The Node PWA server connects with a Hugging Face READ token stored as a server-side secret.

The current PWA can use the official public `Qwen/Qwen-Image-Edit-2509` Space immediately. To switch to this private Space later, set the PWA server variables:

- `HF_SPACE_ID=sitaremalkoc/perde-ai-studio-model`
- `HF_API_NAME=/generate`
- `HF_API_MODE=perde-custom`

Do not add any API tokens to this repository.
