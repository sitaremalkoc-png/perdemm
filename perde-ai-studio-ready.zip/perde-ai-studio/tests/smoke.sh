#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export NODE_ENV=development
export APP_PASSWORD='test-only-password-123'
export SESSION_SECRET='test-only-session-secret-at-least-32-chars'
export AI_MOCK=true
export PORT=3199
node server.js > /tmp/perde-ai-studio-test.log 2>&1 &
PID=$!
cleanup(){ kill "$PID" 2>/dev/null || true; }
trap cleanup EXIT
for i in $(seq 1 30); do
  if curl -fsS http://127.0.0.1:3199/healthz >/tmp/perde-health.json; then break; fi
  sleep 0.3
done
node -e "const x=require('/tmp/perde-health.json'); if(!x.ok) process.exit(1); console.log('healthz OK')"
LOGIN=$(curl -fsS -c /tmp/perde-cookies.txt -H 'Content-Type: application/json' -d '{"password":"test-only-password-123"}' http://127.0.0.1:3199/api/login)
node -e "const x=JSON.parse(process.argv[1]); if(!x.ok) process.exit(1); console.log('login OK')" "$LOGIN"
python - <<'PY'
from PIL import Image
Image.new('RGB',(32,32),(220,220,220)).save('/tmp/perde-test.png')
PY
START=$(curl -fsS -b /tmp/perde-cookies.txt -F 'room=@/tmp/perde-test.png;type=image/png' -F 'fabric=@/tmp/perde-test.png;type=image/png' -F 'privacyConsent=true' -F 'curtainType=Fon + tül' -F 'pleat=Normal pile' http://127.0.0.1:3199/api/generate)
JOB=$(node -e "console.log(JSON.parse(process.argv[1]).jobId)" "$START")
for i in $(seq 1 30); do
  STATUS=$(curl -fsS -b /tmp/perde-cookies.txt "http://127.0.0.1:3199/api/jobs/$JOB")
  DONE=$(node -e "const x=JSON.parse(process.argv[1]); console.log(x.status==='completed'?'yes':'no')" "$STATUS")
  if [ "$DONE" = yes ]; then
    node -e "const x=JSON.parse(process.argv[1]); if(!x.imageData?.startsWith('data:image/svg+xml;base64,')) process.exit(1); console.log('mock generation OK')" "$STATUS"
    exit 0
  fi
  sleep 0.3
done
echo "Job did not complete in time" >&2
cat /tmp/perde-ai-studio-test.log >&2
exit 1
