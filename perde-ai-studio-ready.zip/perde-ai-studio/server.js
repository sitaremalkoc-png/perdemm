import 'dotenv/config';
import express from 'express';
import multer from 'multer';
import helmet from 'helmet';
import { createHmac, randomUUID, timingSafeEqual } from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { Client, handle_file } from '@gradio/client';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const PORT = Number(process.env.PORT || 3000);
const IS_PROD = process.env.NODE_ENV === 'production';
const APP_PASSWORD = process.env.APP_PASSWORD || '';
const SESSION_SECRET = process.env.SESSION_SECRET || '';
const HF_TOKEN = process.env.HF_TOKEN || '';
const HF_SPACE_ID = process.env.HF_SPACE_ID || 'Qwen/Qwen-Image-Edit-2509';
const HF_API_NAME = process.env.HF_API_NAME || '/infer';
const HF_API_MODE = process.env.HF_API_MODE || 'qwen-2509-gallery';
const HF_STEPS = Math.max(8, Math.min(30, Number(process.env.HF_STEPS || 20)));
const AI_MOCK = process.env.AI_MOCK === 'true' && !IS_PROD;
const COOKIE_NAME = 'perde_session';
const SESSION_TTL_SECONDS = 8 * 60 * 60;
const MAX_UPLOAD_BYTES = 12 * 1024 * 1024;

if (!SESSION_SECRET || SESSION_SECRET.length < 32) {
  console.warn('[Perde AI] SESSION_SECRET eksik veya 32 karakterden kısa. Giriş oturumu üretim için hazır değil.');
}
if (!APP_PASSWORD) {
  console.warn('[Perde AI] APP_PASSWORD ayarlanmamış. Giriş yapılandırılmadan uygulama kullanılamaz.');
}

app.disable('x-powered-by');
app.set('trust proxy', 1);
app.use(helmet({
  contentSecurityPolicy: {
    directives: {
      defaultSrc: ["'self'"],
      baseUri: ["'self'"],
      connectSrc: ["'self'"],
      fontSrc: ["'self'", 'data:'],
      formAction: ["'self'"],
      frameAncestors: ["'none'"],
      imgSrc: ["'self'", 'blob:', 'data:'],
      objectSrc: ["'none'"],
      scriptSrc: ["'self'"],
      styleSrc: ["'self'", "'unsafe-inline'"],
      upgradeInsecureRequests: IS_PROD ? [] : null
    }
  },
  crossOriginEmbedderPolicy: false
}));
app.use(express.json({ limit: '16kb' }));

const loginAttempts = new Map();
const jobs = new Map();
let activeJobId = null;
let gradioClientPromise = null;

function safeEqual(a, b) {
  const aa = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (aa.length !== bb.length) return false;
  return timingSafeEqual(aa, bb);
}

function makeSessionCookie() {
  const payload = Buffer.from(JSON.stringify({ exp: Date.now() + SESSION_TTL_SECONDS * 1000 })).toString('base64url');
  const signature = createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  return `${payload}.${signature}`;
}

function isValidSession(req) {
  if (!SESSION_SECRET || SESSION_SECRET.length < 32) return false;
  const cookieHeader = req.headers.cookie || '';
  const token = cookieHeader.split(';').map(v => v.trim()).find(v => v.startsWith(`${COOKIE_NAME}=`))?.slice(COOKIE_NAME.length + 1);
  if (!token) return false;
  const [payload, signature] = token.split('.');
  if (!payload || !signature) return false;
  const expected = createHmac('sha256', SESSION_SECRET).update(payload).digest('base64url');
  if (!safeEqual(signature, expected)) return false;
  try {
    const data = JSON.parse(Buffer.from(payload, 'base64url').toString('utf8'));
    return Number(data.exp) > Date.now();
  } catch {
    return false;
  }
}

function requireAuth(req, res, next) {
  if (!isValidSession(req)) return res.status(401).json({ error: 'Oturum süresi doldu. Yeniden giriş yap.' });
  next();
}

function sameOrigin(req, res, next) {
  const origin = req.headers.origin;
  if (origin) {
    try {
      if (new URL(origin).host !== req.headers.host) return res.status(403).json({ error: 'İstek kaynağı doğrulanamadı.' });
    } catch {
      return res.status(403).json({ error: 'İstek kaynağı doğrulanamadı.' });
    }
  }
  next();
}

function rateLimitLogin(req, res, next) {
  const ip = req.ip || req.socket.remoteAddress || 'unknown';
  const now = Date.now();
  const record = loginAttempts.get(ip) || { count: 0, resetAt: now + 15 * 60 * 1000 };
  if (now > record.resetAt) {
    record.count = 0;
    record.resetAt = now + 15 * 60 * 1000;
  }
  if (record.count >= 8) return res.status(429).json({ error: 'Çok fazla deneme yapıldı. 15 dakika sonra tekrar dene.' });
  record.count += 1;
  loginAttempts.set(ip, record);
  next();
}

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_UPLOAD_BYTES, files: 2 },
  fileFilter: (_req, file, cb) => {
    const allowed = ['image/jpeg', 'image/png', 'image/webp'];
    if (!allowed.includes(file.mimetype)) return cb(new Error('Yalnızca JPG, PNG veya WEBP görsel yükleyebilirsin.'));
    cb(null, true);
  }
});

function buildCurtainPrompt({ curtainType, pleat, colorHint, notes }) {
  const typeMap = {
    'Fon perde': 'full-length decorative side drapes framing the window',
    'Tül perde': 'light translucent sheer curtains covering the window',
    'Kruvaze': 'elegant crossed-over (kruvaze) curtain panels, symmetrically draped',
    'Fon + tül': 'a layered window treatment with sheer inner curtains and decorative outer side drapes',
    'Avangart': 'luxurious classic/avangarde drapery with refined folds and elegant detailing'
  };
  const pleatMap = {
    'Sık pile': 'dense, evenly spaced deep pleats',
    'Normal pile': 'natural medium-density pleats',
    'Seyrek pile': 'soft, wider-spaced pleats',
    'Dalga pile': 'even, continuous wave-fold draping'
  };
  const chosenType = typeMap[curtainType] || typeMap['Fon + tül'];
  const chosenPleat = pleatMap[pleat] || pleatMap['Normal pile'];
  const color = colorHint?.trim() ? `Fabric color note: ${colorHint.trim()}.` : '';
  const extra = notes?.trim() ? `Additional instructions: ${notes.trim()}.` : '';
  return [
    'Image 1 is the original room photograph and must remain the base composition. Image 2 is the exact fabric reference sample.',
    `Edit only the window treatment in image 1. Add ${chosenType} made from the fabric shown in image 2.`,
    `Use ${chosenPleat}. Preserve the reference fabric\'s visible color, weave, texture, motif, and pattern as faithfully as possible; do not invent a different print or material.`,
    'Fit the curtains naturally to the existing windows, rods or ceiling track, with realistic gravity, folds, scale, perspective, and room lighting. Keep the curtains floor-length unless the room geometry clearly requires otherwise.',
    'Keep all other room details unchanged: architecture, window frames, walls, ceiling, furniture, flooring, objects, camera angle, and lighting. Do not add text, logos, people, or extra decor. Photorealistic interior-design visualization.',
    color,
    extra
  ].filter(Boolean).join(' ');
}

async function getGradioClient() {
  if (!HF_TOKEN) throw new Error('HF_TOKEN ayarlanmamış. Hugging Face erişim tokenını sunucu ortam değişkenine ekle.');
  if (!gradioClientPromise) {
    gradioClientPromise = Client.connect(HF_SPACE_ID, { token: HF_TOKEN, events: ['data', 'status'] });
    gradioClientPromise.catch(() => { gradioClientPromise = null; });
  }
  return gradioClientPromise;
}

function findFileRef(value) {
  if (!value) return null;
  if (typeof value === 'string') {
    if (/^https?:\/\//i.test(value) || value.startsWith('/')) return { url: value };
    return null;
  }
  if (Array.isArray(value)) {
    for (const item of value) {
      const found = findFileRef(item);
      if (found) return found;
    }
    return null;
  }
  if (typeof value === 'object') {
    if (typeof value.url === 'string' || typeof value.path === 'string') return value;
    for (const item of Object.values(value)) {
      const found = findFileRef(item);
      if (found) return found;
    }
  }
  return null;
}

function spaceBaseUrl(spaceId) {
  return `https://${spaceId.toLowerCase().replaceAll('/', '-')}.hf.space`;
}

async function getResultDataUrl(resultData) {
  const fileRef = findFileRef(resultData);
  if (!fileRef) throw new Error('Yapay zekâ sonucu görsel dosyası içermiyor.');
  const rawUrl = fileRef.url || fileRef.path;
  if (rawUrl.startsWith('data:image/')) return rawUrl;
  let imageUrl;
  if (/^https?:\/\//i.test(rawUrl)) imageUrl = rawUrl;
  else if (rawUrl.startsWith('/')) imageUrl = new URL(rawUrl, spaceBaseUrl(HF_SPACE_ID)).toString();
  else imageUrl = new URL(`/gradio_api/file=${encodeURIComponent(rawUrl)}`, spaceBaseUrl(HF_SPACE_ID)).toString();
  const response = await fetch(imageUrl, {
    headers: HF_TOKEN ? { Authorization: `Bearer ${HF_TOKEN}` } : {},
    signal: AbortSignal.timeout(45_000)
  });
  if (!response.ok) throw new Error(`Sonuç görseli indirilemedi (HTTP ${response.status}).`);
  const contentType = response.headers.get('content-type') || 'image/png';
  if (!contentType.startsWith('image/')) throw new Error('Yapay zekâ geçerli bir görsel döndürmedi.');
  const buffer = Buffer.from(await response.arrayBuffer());
  if (buffer.length > 18 * 1024 * 1024) throw new Error('Sonuç görseli beklenenden büyük.');
  return `data:${contentType};base64,${buffer.toString('base64')}`;
}

function safeErrorMessage(error) {
  const raw = String(error?.message || 'Beklenmeyen bir hata oluştu.');
  return raw
    .replace(/hf_[A-Za-z0-9_-]+/g, '[gizli token]')
    .replace(/Bearer\s+\S+/gi, 'Bearer [gizli]')
    .slice(0, 360);
}

async function runMockJob(jobId) {
  const job = jobs.get(jobId);
  if (!job) return;
  job.status = 'running';
  job.progress = 30;
  await new Promise(resolve => setTimeout(resolve, 1200));
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="900" height="600" viewBox="0 0 900 600"><rect width="900" height="600" fill="#eee8df"/><rect x="170" y="65" width="560" height="410" rx="8" fill="#d5d0c8"/><rect x="255" y="105" width="390" height="325" fill="#dce7e9" stroke="#8d9697" stroke-width="12"/><path d="M235 90 Q180 250 235 455 L300 455 Q260 250 300 90Z" fill="#b5a1a0"/><path d="M665 90 Q720 250 665 455 L600 455 Q640 250 600 90Z" fill="#b5a1a0"/><path d="M235 90 Q250 160 235 455 M665 90 Q650 160 665 455" fill="none" stroke="#f4ece8" stroke-width="9" opacity=".7"/><text x="450" y="535" font-family="Arial" font-size="22" text-anchor="middle" fill="#625a54">Yerel arayüz testi — gerçek AI çıktısı değil</text></svg>`;
  job.imageData = `data:image/svg+xml;base64,${Buffer.from(svg).toString('base64')}`;
  job.status = 'completed';
  job.progress = 100;
  job.finishedAt = Date.now();
}

async function runHuggingFaceJob(jobId, room, fabric, prompt) {
  const jobState = jobs.get(jobId);
  if (!jobState) return;
  try {
    jobState.status = 'connecting';
    jobState.progress = 4;
    const client = await getGradioClient();
    const roomRef = handle_file(Buffer.from(room.buffer));
    const fabricRef = handle_file(Buffer.from(fabric.buffer));
    let endpoint;
    let payload;
    if (HF_API_MODE === 'qwen-2509-gallery') {
      endpoint = HF_API_NAME;
      const gallery = [{ image: roomRef, caption: null }, { image: fabricRef, caption: null }];
      payload = [gallery, prompt, 0, true, 3.5, HF_STEPS, null, null, false];
    } else if (HF_API_MODE === 'perde-custom') {
      endpoint = HF_API_NAME || '/generate';
      payload = [roomRef, fabricRef, prompt, 0, HF_STEPS];
    } else {
      throw new Error('HF_API_MODE tanınmıyor.');
    }

    jobState.status = 'queued';
    jobState.progress = 8;
    const remoteJob = client.submit(endpoint, payload);
    let resultData = null;
    for await (const message of remoteJob) {
      if (message?.type === 'status') {
        const position = Number(message.position || 0);
        jobState.queuePosition = Number.isFinite(position) && position > 0 ? position : null;
        const stage = String(message.stage || '').toLowerCase();
        jobState.progress = Math.max(jobState.progress, stage === 'generating' ? 45 : 12);
        jobState.status = stage === 'generating' ? 'running' : stage === 'error' ? 'failed' : 'queued';
      }
      if (message?.type === 'data') {
        resultData = message.data;
        jobState.progress = 90;
      }
    }
    if (!resultData && typeof remoteJob.result === 'function') resultData = await remoteJob.result();
    if (!resultData) throw new Error('Hugging Face işi sonuç döndürmedi.');
    jobState.imageData = await getResultDataUrl(resultData);
    jobState.status = 'completed';
    jobState.progress = 100;
    jobState.finishedAt = Date.now();
  } catch (error) {
    jobState.status = 'failed';
    jobState.error = safeErrorMessage(error);
    jobState.finishedAt = Date.now();
  } finally {
    if (activeJobId === jobId) activeJobId = null;
  }
}

app.get('/healthz', (_req, res) => res.json({ ok: true, app: 'Perde AI Studio', version: '0.2.0' }));

app.get('/api/status', (req, res) => {
  res.set('Cache-Control', 'no-store');
  res.json({
    authenticated: isValidSession(req),
    aiReady: AI_MOCK || Boolean(HF_TOKEN),
    mock: AI_MOCK,
    model: AI_MOCK ? 'Yerel arayüz testi' : 'Qwen-Image-Edit-2509 · Hugging Face ZeroGPU',
    steps: HF_STEPS
  });
});

app.post('/api/login', sameOrigin, rateLimitLogin, (req, res) => {
  if (!APP_PASSWORD || !SESSION_SECRET || SESSION_SECRET.length < 32) {
    return res.status(503).json({ error: 'Sunucu sahibi henüz APP_PASSWORD ve SESSION_SECRET ayarlamadı.' });
  }
  const password = req.body?.password || '';
  if (!safeEqual(password, APP_PASSWORD)) return res.status(401).json({ error: 'Şifre doğru değil.' });
  const cookie = makeSessionCookie();
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=${cookie}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${SESSION_TTL_SECONDS}${IS_PROD ? '; Secure' : ''}`);
  res.set('Cache-Control', 'no-store');
  res.json({ ok: true });
});

app.post('/api/logout', sameOrigin, (_req, res) => {
  res.setHeader('Set-Cookie', `${COOKIE_NAME}=; HttpOnly; SameSite=Lax; Path=/; Max-Age=0${IS_PROD ? '; Secure' : ''}`);
  res.json({ ok: true });
});

app.post('/api/generate', requireAuth, sameOrigin, upload.fields([
  { name: 'room', maxCount: 1 },
  { name: 'fabric', maxCount: 1 }
]), async (req, res) => {
  res.set('Cache-Control', 'no-store');
  const room = req.files?.room?.[0];
  const fabric = req.files?.fabric?.[0];
  if (!room || !fabric) return res.status(400).json({ error: 'Oda fotoğrafı ve kumaş fotoğrafı birlikte gerekli.' });
  if (req.body?.privacyConsent !== 'true') return res.status(400).json({ error: 'Görsellerin Hugging Face üzerinde işlenmesine onay vermen gerekiyor.' });
  if (!AI_MOCK && !HF_TOKEN) return res.status(503).json({ error: 'Hugging Face tokenı sunucuya eklenmemiş.' });
  if (activeJobId) return res.status(429).json({ error: 'Bir görsel şu anda hazırlanıyor. Bitmesini bekleyelim.' });

  const prompt = buildCurtainPrompt({
    curtainType: req.body?.curtainType,
    pleat: req.body?.pleat,
    colorHint: req.body?.colorHint,
    notes: req.body?.notes
  });
  const jobId = randomUUID();
  jobs.set(jobId, { id: jobId, status: 'starting', progress: 0, createdAt: Date.now(), imageData: null, error: null, queuePosition: null });
  activeJobId = jobId;
  if (AI_MOCK) {
    runMockJob(jobId).finally(() => { if (activeJobId === jobId) activeJobId = null; });
  } else {
    runHuggingFaceJob(jobId, room, fabric, prompt);
  }
  res.status(202).json({ jobId, message: 'Görsel sıraya alındı.' });
});

app.get('/api/jobs/:id', requireAuth, (req, res) => {
  res.set('Cache-Control', 'no-store');
  const job = jobs.get(req.params.id);
  if (!job) return res.status(404).json({ error: 'İş bulunamadı veya süresi doldu.' });
  const body = {
    id: job.id,
    status: job.status,
    progress: job.progress,
    queuePosition: job.queuePosition,
    error: job.error
  };
  if (job.status === 'completed') body.imageData = job.imageData;
  res.json(body);
});

app.use(express.static(path.join(__dirname, 'public'), {
  etag: true,
  maxAge: IS_PROD ? '1h' : 0,
  setHeaders(res, filePath) {
    if (filePath.endsWith('sw.js') || filePath.endsWith('index.html')) res.setHeader('Cache-Control', 'no-cache');
  }
}));

app.get('*', (_req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((error, _req, res, _next) => {
  const message = error?.message || 'Beklenmeyen bir hata oluştu.';
  const status = error?.code === 'LIMIT_FILE_SIZE' ? 413 : 400;
  res.status(status).json({ error: message.slice(0, 220) });
});

setInterval(() => {
  const cutoff = Date.now() - 30 * 60 * 1000;
  for (const [id, job] of jobs) {
    if ((job.finishedAt || job.createdAt) < cutoff && id !== activeJobId) jobs.delete(id);
  }
  for (const [ip, item] of loginAttempts) if (Date.now() > item.resetAt + 60 * 60 * 1000) loginAttempts.delete(ip);
}, 5 * 60 * 1000).unref();

app.listen(PORT, () => {
  console.log(`[Perde AI Studio] listening on ${PORT}; mode=${AI_MOCK ? 'mock' : 'huggingface'}; space=${HF_SPACE_ID}`);
});
