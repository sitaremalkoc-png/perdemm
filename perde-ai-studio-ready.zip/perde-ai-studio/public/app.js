const $ = (id) => document.getElementById(id);
let installPrompt = null;
let pollTimer = null;

async function api(path, options = {}) {
  const response = await fetch(path, { credentials: 'same-origin', ...options });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || `İstek başarısız (${response.status}).`);
  return data;
}

function showStudio(isAuthed) {
  $('loginView').classList.toggle('hidden', isAuthed);
  $('studioView').classList.toggle('hidden', !isAuthed);
  $('logoutButton').classList.toggle('hidden', !isAuthed);
}

function setBadge(text, type = '') {
  const badge = $('connectionBadge');
  badge.textContent = text;
  badge.className = `status-pill ${type}`.trim();
}

async function refreshStatus() {
  try {
    const status = await api('/api/status');
    showStudio(status.authenticated);
    if (status.aiReady) setBadge(status.mock ? 'Arayüz test modu' : 'AI bağlantısı hazır', status.mock ? 'warn' : 'ready');
    else setBadge('AI anahtarı bekleniyor', 'warn');
  } catch {
    setBadge('Bağlantı kontrol edilemedi', 'warn');
  }
}

$('loginForm').addEventListener('submit', async (event) => {
  event.preventDefault();
  $('loginError').textContent = '';
  const button = event.submitter;
  if (button) button.disabled = true;
  try {
    await api('/api/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ password: $('passwordInput').value })
    });
    $('passwordInput').value = '';
    await refreshStatus();
  } catch (error) {
    $('loginError').textContent = error.message;
  } finally {
    if (button) button.disabled = false;
  }
});

$('logoutButton').addEventListener('click', async () => {
  try { await api('/api/logout', { method: 'POST' }); } catch {}
  showStudio(false);
});

function bindPreview(inputId, imageId, labelId) {
  $(inputId).addEventListener('change', () => {
    const file = $(inputId).files?.[0];
    const img = $(imageId);
    const card = $(inputId).closest('.upload-card');
    if (!file) {
      img.src = '';
      img.classList.add('hidden');
      card.classList.remove('has-image');
      $(labelId).textContent = 'Fotoğraf seç +';
      updateGenerateButton();
      return;
    }
    if (!['image/jpeg', 'image/png', 'image/webp'].includes(file.type)) {
      alert('JPG, PNG veya WEBP dosyası seç.');
      $(inputId).value = '';
      return;
    }
    img.src = URL.createObjectURL(file);
    img.classList.remove('hidden');
    card.classList.add('has-image');
    $(labelId).textContent = 'Değiştir +';
    updateGenerateButton();
  });
}

bindPreview('roomInput', 'roomPreview', 'roomLabel');
bindPreview('fabricInput', 'fabricPreview', 'fabricLabel');
$('privacyConsent').addEventListener('change', updateGenerateButton);

function updateGenerateButton() {
  $('generateButton').disabled = !($('roomInput').files?.[0] && $('fabricInput').files?.[0] && $('privacyConsent').checked);
}

function setProgress(status) {
  const map = {
    starting: ['Başlatılıyor…', 'Görseller hazırlanıyor.'],
    connecting: ['AI servisine bağlanıyor…', 'Hugging Face alanı uyandırılıyor olabilir.'],
    queued: ['Sırada bekliyor…', status.queuePosition ? `Kuyrukta ${status.queuePosition}. sıradasın.` : 'Ücretsiz GPU sırası bekleniyor.'],
    running: ['Perde tasarımın hazırlanıyor…', 'Kumaş dokusu odaya uygulanıyor.'],
    completed: ['Tasarım hazır', 'Görsel oluşturuldu.'],
    failed: ['İşlem tamamlanamadı', status.error || 'Bir hata oluştu.']
  };
  const item = map[status.status] || ['İşlem sürüyor…', 'Biraz daha bekleyelim.'];
  $('progressTitle').textContent = item[0];
  $('progressText').textContent = item[1];
  $('progressBar').style.width = `${Math.max(5, status.progress || 5)}%`;
}

function stopPolling() {
  if (pollTimer) clearTimeout(pollTimer);
  pollTimer = null;
}

async function pollJob(jobId) {
  try {
    const status = await api(`/api/jobs/${encodeURIComponent(jobId)}`);
    setProgress(status);
    if (status.status === 'completed') {
      stopPolling();
      $('progressBox').classList.add('hidden');
      $('resultBox').classList.remove('hidden');
      $('resultImage').src = status.imageData;
      $('downloadButton').dataset.image = status.imageData;
      $('generateButton').disabled = false;
      $('generateButton').querySelector('span').textContent = 'Perdeyi odamda göster';
      return;
    }
    if (status.status === 'failed') {
      stopPolling();
      $('progressBox').classList.add('hidden');
      $('resultError').textContent = status.error || 'Görsel oluşturulamadı.';
      $('resultError').classList.remove('hidden');
      $('generateButton').disabled = false;
      $('generateButton').querySelector('span').textContent = 'Tekrar dene';
      return;
    }
    pollTimer = setTimeout(() => pollJob(jobId), 2200);
  } catch (error) {
    stopPolling();
    $('progressBox').classList.add('hidden');
    $('resultError').textContent = error.message;
    $('resultError').classList.remove('hidden');
    $('generateButton').disabled = false;
  }
}

$('generateButton').addEventListener('click', async () => {
  $('resultError').classList.add('hidden');
  $('emptyResult').classList.add('hidden');
  $('resultBox').classList.add('hidden');
  $('progressBox').classList.remove('hidden');
  $('generateButton').disabled = true;
  $('generateButton').querySelector('span').textContent = 'Hazırlanıyor…';
  setProgress({ status: 'starting', progress: 5 });
  stopPolling();
  const form = new FormData();
  form.append('room', $('roomInput').files[0]);
  form.append('fabric', $('fabricInput').files[0]);
  form.append('curtainType', $('curtainType').value);
  form.append('pleat', $('pleat').value);
  form.append('colorHint', $('colorHint').value);
  form.append('notes', $('notes').value);
  form.append('privacyConsent', $('privacyConsent').checked ? 'true' : 'false');
  try {
    const response = await fetch('/api/generate', { method: 'POST', body: form, credentials: 'same-origin' });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.error || 'İşlem başlatılamadı.');
    pollJob(data.jobId);
  } catch (error) {
    $('progressBox').classList.add('hidden');
    $('resultError').textContent = error.message;
    $('resultError').classList.remove('hidden');
    $('generateButton').disabled = false;
    $('generateButton').querySelector('span').textContent = 'Tekrar dene';
  }
});

$('downloadButton').addEventListener('click', () => {
  const src = $('downloadButton').dataset.image;
  if (!src) return;
  const a = document.createElement('a');
  a.href = src;
  a.download = `perde-ai-tasarim-${new Date().toISOString().slice(0,10)}.png`;
  document.body.appendChild(a);
  a.click();
  a.remove();
});

$('newDesignButton').addEventListener('click', () => {
  $('resultBox').classList.add('hidden');
  $('resultError').classList.add('hidden');
  $('emptyResult').classList.remove('hidden');
  $('resultImage').src = '';
  $('downloadButton').dataset.image = '';
  $('generateButton').disabled = !($('roomInput').files?.[0] && $('fabricInput').files?.[0] && $('privacyConsent').checked);
});

window.addEventListener('beforeinstallprompt', (event) => {
  event.preventDefault();
  installPrompt = event;
  $('installButton').classList.remove('hidden');
});
$('installButton').addEventListener('click', async () => {
  if (!installPrompt) return;
  installPrompt.prompt();
  await installPrompt.userChoice;
  installPrompt = null;
  $('installButton').classList.add('hidden');
});

if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => navigator.serviceWorker.register('/sw.js').catch(() => {}));
}
refreshStatus();
